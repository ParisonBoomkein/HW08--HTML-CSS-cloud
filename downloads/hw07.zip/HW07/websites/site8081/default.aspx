﻿<%@ Page Language="C#" ResponseEncoding="utf-8" %>
<!DOCTYPE html>
<html lang="th">
<head>
<meta charset="UTF-8">
<title>Server Info - Parison Boonkeim</title>
<style>
  * {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
  }

  body {
    font-family: 'Segoe UI', Tahoma, Arial, sans-serif;
    background: linear-gradient(135deg, #6a11cb 0%, #d5006d 50%, #ff6fa5 100%);
    min-height: 100vh;
    display: flex;
    justify-content: center;
    align-items: center;
    padding: 40px 15px;
  }

  .panel {
    background-color: #ffffff;
    max-width: 640px;
    width: 100%;
    border-radius: 20px;
    box-shadow: 0 15px 35px rgba(90, 20, 130, 0.4);
    overflow: hidden;
  }

  .panel-header {
    background: linear-gradient(135deg, #7b2ff7, #d5006d);
    color: #ffffff;
    padding: 30px 35px 24px;
  }

  .panel-header h1 {
    font-size: 22px;
    margin-bottom: 6px;
  }

  .panel-header .subtitle {
    color: #f6d9ec;
    font-size: 13px;
  }

  .panel-body {
    padding: 30px 35px;
  }

  table {
    width: 100%;
    border-collapse: collapse;
  }

  td {
    padding: 13px 8px;
    border-bottom: 1px solid #f3e3f0;
    vertical-align: top;
  }

  tr:last-child td {
    border-bottom: none;
  }

  td.label {
    font-weight: 600;
    color: #8a4b9e;
    width: 45%;
    font-size: 14px;
  }

  td.value {
    color: #4a1a5c;
    font-family: Consolas, monospace;
    font-size: 13px;
    word-break: break-all;
  }

  .welcome {
    margin-top: 22px;
    background: linear-gradient(135deg, #f6d9ec, #ffe3f1);
    border-left: 4px solid #d5006d;
    padding: 14px 18px;
    border-radius: 8px;
    color: #6a11cb;
    font-size: 14px;
  }

  .footer-note {
    background-color: #fbf1f9;
    text-align: center;
    padding: 14px;
    font-size: 12px;
    color: #a06bb0;
  }
</style>
</head>
<body>
  <div class="panel">
    <div class="panel-header">
      <h1>ยินดีต้อนรับสู่เว็บไซต์ ASP.NET</h1>
      <div class="subtitle">Homework #7 - IIS Website 2 (Port 8081)</div>
    </div>

    <div class="panel-body">
      <table>
        <tr>
          <td class="label">วันและเวลาปัจจุบัน (Server Time)</td>
          <td class="value"><%= DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss") %></td>
        </tr>
        <tr>
          <td class="label">ชื่อเครื่อง Server</td>
          <td class="value"><%= Environment.MachineName %></td>
        </tr>
        <tr>
          <td class="label">ระบบปฏิบัติการ</td>
          <td class="value"><%= Environment.OSVersion.ToString() %></td>
        </tr>
        <tr>
          <td class="label">IP Address ของผู้เข้าชม</td>
          <td class="value"><%= Request.UserHostAddress %></td>
        </tr>
        <tr>
          <td class="label">Browser ของผู้เข้าชม</td>
          <td class="value"><%= Request.UserAgent %></td>
        </tr>
      </table>

      <div class="welcome">
        <b>Homework 7 - นาย ปริศร บุญเคลิ้ม (6810301022)</b><br>
        สาขาวิศวกรรมคอมพิวเตอร์ | สถาบันเทคโนโลยีจิตรลดา
      </div>
    </div>


  </div>
</body>
</html>
